# Mosaic-PS1

The aim of this project is to detect handritten captcha from .jpg format. <br />

The Captcha might contain letters or 7 emojis. The 7 emojis which can be present in the captcha are :- 
1. Checkmark
2. Cloud
3. Croissant
4. Heart
5. Laugh
6. Smile
7. Sun

The "emojis.csv" file contain dataset for the detection of emojis and for letters the EMNIST dataset is used. You can access the dataset for letters from [here](https://www.kaggle.com/datasets/crawford/emnist)
